/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.{html,js}", "./assets/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}